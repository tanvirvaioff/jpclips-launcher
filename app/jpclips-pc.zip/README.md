# JpClips PC — AI Clipper for Windows (NVIDIA GPU)

Run the JpClips AI clipper on your own Windows PC with your GPU.
Much faster than the VPS: transcription (faster-whisper) + face detection (YOLOv8)
run on CUDA.

## What you need (one-time setup)

1. **Windows 10/11, 64-bit**
2. **Python 3.11 (64-bit)** — https://www.python.org/downloads/
   - ⚠️ During install, tick **"Add python.exe to PATH"**
3. **NVIDIA GPU driver** — https://www.nvidia.com/drivers
   - Check with `nvidia-smi` in Command Prompt
4. **ffmpeg** — https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
   - Extract, add the `bin` folder to your PATH
   - Check with `ffmpeg -version` in Command Prompt
5. **CUDA Toolkit** (optional but recommended) — https://developer.nvidia.com/cuda-downloads
   - The installer also pulls CUDA DLLs via pip, so this is a fallback.

## Install (run once)

Double-click **`install.bat`**. It will:
- Install PyTorch with CUDA 12.1 (~2.5 GB download)
- Install faster-whisper, ultralytics (YOLOv8), mediapipe, FastAPI, etc.

Takes 5–15 minutes depending on your internet.

## Run (every time)

Double-click **`start.bat`**, then open **http://localhost:8000** in your browser.

- Put your API keys in **Settings** (top-right gear icon):
  - **AI provider**: Gemini (free), OpenAI (paid, fastest), or Groq (free tier)
  - Keys are stored in your browser only (localStorage)
- Upload a video or paste a video file path, click Generate.
- Clips appear in **Generated Shorts** — download the ones you like.

> 💡 With OpenAI selected as provider, transcription uses OpenAI's Whisper API
> (cloud, ~$0.006/min). With Gemini/Groq, transcription runs on YOUR GPU —
> free and fast.

## How it works

- `start.bat` sets `WHISPER_DEVICE=cuda` + `WHISPER_COMPUTE=float16`
  → faster-whisper transcribes on your GPU (~5–10x faster than CPU)
- YOLOv8 face detection auto-uses CUDA via PyTorch
- Backend: FastAPI (`backend/`, served by `pc_server.py` on port 8000)
- Frontend: the same React UI, pre-built into `frontend/` and served by the backend
- Each clip job runs as `python -u main.py` subprocess (same as server)

## Files

| File / folder | What it is |
|---|---|
| `install.bat` | One-time installer |
| `start.bat` | Starts the app (double-click every time) |
| `requirements.txt` | Python packages |
| `pc_server.py` | Entry point: patches Windows quirks, serves API + UI |
| `backend/` | All backend Python files (`app.py`, `main.py`, …) + `pc_compat.py` |
| `frontend/` | Built React UI (static files) |

## Troubleshooting

- **`python` not recognized** → reinstall Python with "Add to PATH" ticked
- **No GPU / slow** → run `nvidia-smi`; if it fails, install NVIDIA driver.
  The app still works on CPU, just slower.
- **CUDA out of memory** → close other GPU apps (games, etc.), or set in
  `start.bat`: `set WHISPER_COMPUTE=int8` (uses less VRAM)
- **ffmpeg not found** → add ffmpeg `bin` folder to PATH, restart Command Prompt
- **Port 8000 busy** → close the other app, or edit `start.bat` to use another port
- **Model downloads** → first run downloads Whisper `small` (~500 MB) and
  YOLOv8n (~6 MB) automatically to `%USERPROFILE%\.cache`

## Limitations vs the VPS version

- No HTTPS / domain — it's `http://localhost:8000` on your PC only
- No user accounts / billing — single user, your PC
- YouTube URL download may be blocked (same bot protection as VPS);
  downloading the video yourself and uploading the file always works
- Keep your PC on while jobs run — closing the window stops processing
