"""ai33.pro TTS-based video dubbing.

Flow: transcribe (faster-whisper) -> translate segments (Gemini REST) ->
ai33.pro TTS per segment -> assemble timeline audio -> mux into video.

Auth: xi-api-key header for ai33.pro. Gemini key comes from the
server-side GEMINI_API_KEY env var.
"""

import os
import time
import json
import shutil
import subprocess
import tempfile

import httpx

AI33_BASE = "https://api.ai33.pro"
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"

SUPPORTED_LANGUAGES = {
    "en": "English", "es": "Spanish", "fr": "French", "de": "German",
    "it": "Italian", "pt": "Portuguese", "pl": "Polish", "hi": "Hindi",
    "ja": "Japanese", "ko": "Korean", "zh": "Chinese", "ar": "Arabic",
    "ru": "Russian", "tr": "Turkish", "nl": "Dutch", "sv": "Swedish",
    "id": "Indonesian", "fil": "Filipino", "ms": "Malay", "vi": "Vietnamese",
    "th": "Thai", "uk": "Ukrainian", "el": "Greek", "cs": "Czech",
    "fi": "Finnish", "ro": "Romanian", "da": "Danish", "bg": "Bulgarian",
    "hr": "Croatian", "sk": "Slovak", "ta": "Tamil",
}

_VOICE_PROVIDERS = ["elevenlabs", "minimax", "edge", "kokoro", "fishaudio",
                    "vbee", "clone"]


def _ffprobe_dur(path):
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, timeout=60)
        return float(r.stdout.strip())
    except Exception:
        return 0.0


def ai33_list_voices(api_key, provider="elevenlabs", page=1, page_size=100,
                     search=""):
    """List voices from ai33.pro. Returns list of dicts."""
    out = []
    with httpx.Client(timeout=60.0) as client:
        for prov in ([provider] if provider else _VOICE_PROVIDERS):
            pg = 1
            while pg <= 5:
                params = {"provider": prov, "page": pg, "page_size": page_size}
                if search:
                    params["search"] = search
                r = client.get(AI33_BASE + "/v3/voices", params=params,
                               headers={"xi-api-key": api_key})
                if r.status_code != 200:
                    break
                try:
                    j = r.json()
                except Exception:
                    break
                data = j.get("data") or j.get("voices") or []
                if isinstance(data, dict):
                    data = data.get("list") or data.get("items") or []
                if not data:
                    break
                prefix = prov + "_"
                for v in data:
                    vid = str(v.get("voice_id") or v.get("id") or "")
                    if not vid:
                        continue
                    if not vid.startswith(prefix):
                        vid = prefix + vid
                    out.append({
                        "voice_id": vid,
                        "name": v.get("name") or v.get("voice_name") or vid,
                        "language": v.get("language") or v.get("locale") or "",
                        "gender": v.get("gender") or "",
                        "provider": prov,
                    })
                if len(data) < page_size:
                    break
                pg += 1
    return out


def ai33_tts_to_file(text, voice_id, api_key, out_path, speed=1.0,
                     timeout_s=1800):
    """TTS one text via ai33.pro, download audio to out_path. Returns out_path."""
    text = (text or "").strip()
    if not text:
        raise ValueError("empty TTS text")
    # ai33 truncates long single requests (~35s) — split into ~400 char pieces
    pieces, cur = [], ""
    for sent in text.replace("\n", " ").split(". "):
        if len(cur) + len(sent) + 2 <= 400:
            cur = (cur + ". " + sent).strip(". ") if cur else sent
        else:
            if cur:
                pieces.append(cur)
            cur = sent
    if cur:
        pieces.append(cur)
    if not pieces:
        raise ValueError("empty TTS text after split")

    part_files = []
    tmpdir = tempfile.mkdtemp(prefix="ai33tts_")
    try:
        with httpx.Client(timeout=300.0) as client:
            for pi, ptext in enumerate(pieces):
                files = {}  # no files, but endpoint expects multipart
                data = {"text": ptext, "voice_id": voice_id,
                        "speed": str(speed)}
                r = client.post(AI33_BASE + "/v3/text-to-speech",
                                data=data, files={"_": ("", b"")},
                                headers={"xi-api-key": api_key})
                try:
                    j = r.json()
                except Exception:
                    j = {}
                if r.status_code != 200 or not j.get("success"):
                    raise RuntimeError(
                        "ai33 TTS submit failed (http %s): %s"
                        % (r.status_code, str(j)[:250]))
                task_id = j.get("task_id", "")
                # poll
                waited, audio_url = 0, ""
                while waited < timeout_s:
                    pr = client.get(AI33_BASE + "/v1/task/" + task_id,
                                    headers={"xi-api-key": api_key},
                                    timeout=60.0)
                    try:
                        pj = pr.json()
                    except Exception:
                        pj = {}
                    status = str(pj.get("status", "")).lower()
                    if status == "done":
                        md = pj.get("metadata") or {}
                        audio_url = (md.get("audio_url")
                                     or pj.get("output_uri") or "")
                        break
                    if status == "error":
                        raise RuntimeError(
                            "ai33 TTS task error: %s"
                            % str(pj.get("error") or pj.get("message")
                                  or pj)[:250])
                    time.sleep(8)
                    waited += 8
                if not audio_url:
                    raise RuntimeError("ai33 TTS timed out waiting for audio")
                dl = client.get(audio_url, timeout=300.0)
                pf = os.path.join(tmpdir, "part_%02d.mp3" % pi)
                with open(pf, "wb") as f:
                    f.write(dl.content)
                part_files.append(pf)
        if len(part_files) == 1:
            shutil.move(part_files[0], out_path)
        else:
            lst = os.path.join(tmpdir, "concat.txt")
            with open(lst, "w", encoding="utf-8") as f:
                for pf in part_files:
                    f.write("file '%s'\n" % pf.replace("'", "'\\''"))
            r = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                 "-i", lst, "-c:a", "libmp3lame", "-b:a", "128k", out_path],
                capture_output=True, text=True, timeout=600)
            if r.returncode != 0 or not os.path.exists(out_path):
                raise RuntimeError("TTS parts concat failed: "
                                   + r.stderr[-200:])
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return out_path


def gemini_translate(text, target_lang, gemini_key, model=None):
    """Translate text via Gemini REST API. Returns translated text."""
    model = model or os.environ.get("GEMINI_MODEL", "gemini-3-flash-preview")
    lang_name = SUPPORTED_LANGUAGES.get(target_lang, target_lang)
    prompt = (
        "Translate the following text to %s. "
        "Return ONLY the translated text, no explanations, no quotes.\n\n%s"
        % (lang_name, text))
    url = ("%s/models/%s:generateContent?key=%s"
           % (GEMINI_BASE, model, gemini_key))
    payload = {"contents": [{"parts": [{"text": prompt}]}],
               "generationConfig": {"temperature": 0.3}}
    with httpx.Client(timeout=120.0) as client:
        r = client.post(url, json=payload)
        r.raise_for_status()
        j = r.json()
    try:
        return j["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception:
        raise RuntimeError("Gemini translate parse error: %s" % str(j)[:200])


def dub_video_ai33(video_path, output_path, target_language, ai33_key,
                   voice_id=None, source_language=None,
                   progress_cb=None):
    """Dub a video using ai33.pro TTS. Returns output_path.

    progress_cb(frac, msg) optional.
    """
    gemini_key = os.environ.get("GEMINI_API_KEY", "")
    if not gemini_key:
        raise RuntimeError("Server is missing GEMINI_API_KEY for translation")
    if target_language not in SUPPORTED_LANGUAGES:
        raise ValueError("Unsupported target language: %s" % target_language)

    def prog(f, m):
        print("[ai33-dub] %s" % m, flush=True)
        if progress_cb:
            try:
                progress_cb(f, m)
            except Exception:
                pass

    # default voice: first elevenlabs voice
    if not voice_id:
        prog(0.02, "Loading ai33 voices…")
        voices = ai33_list_voices(ai33_key, provider="elevenlabs")
        if not voices:
            raise RuntimeError("No ai33 voices available (check API key)")
        voice_id = voices[0]["voice_id"]
        prog(0.04, "Using voice: %s" % voices[0]["name"])

    # 1. transcribe
    prog(0.06, "Transcribing audio…")
    from transcribe_backends import transcribe_media
    tr = transcribe_media(video_path)
    segments = [s for s in tr.get("segments", []) if (s.get("text") or "").strip()]
    if not segments:
        raise RuntimeError("No speech found to dub")
    src_lang = tr.get("language") or source_language or "auto"
    prog(0.15, "Found %d speech segments (%s)" % (len(segments), src_lang))

    vid_dur = _ffprobe_dur(video_path)
    workdir = tempfile.mkdtemp(prefix="ai33dub_")
    try:
        # 2+3. translate + TTS per segment
        chunks = []  # (start_sec, wav_path)
        for i, seg in enumerate(segments):
            s, e = float(seg["start"]), float(seg["end"])
            txt = seg["text"].strip()
            prog(0.15 + 0.55 * i / max(1, len(segments)),
                 "Translating+TTS segment %d/%d…" % (i + 1, len(segments)))
            ttxt = gemini_translate(txt, target_language, gemini_key)
            if not ttxt.strip():
                continue
            mp3 = os.path.join(workdir, "seg_%03d.mp3" % i)
            ai33_tts_to_file(ttxt, voice_id, ai33_key, mp3)
            # strip long pauses
            nosil = os.path.join(workdir, "seg_%03d_ns.mp3" % i)
            r = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-i", mp3, "-af",
                 "silenceremove=stop_periods=-1:stop_duration=0.4:"
                 "stop_threshold=-35dB",
                 "-c:a", "libmp3lame", "-b:a", "128k", nosil],
                capture_output=True, timeout=300)
            if r.returncode == 0 and os.path.getsize(nosil) > 1000:
                os.replace(nosil, mp3)
            # fit into slot: speed up if TTS longer than slot (cap 1.5x)
            tts_dur = _ffprobe_dur(mp3)
            slot = max(1.0, e - s)
            wav = os.path.join(workdir, "seg_%03d.wav" % i)
            if tts_dur > slot:
                tempo = min(1.5, tts_dur / slot)
                r = subprocess.run(
                    ["ffmpeg", "-y", "-v", "error", "-i", mp3, "-af",
                     "atempo=%.3f" % tempo, wav],
                    capture_output=True, timeout=300)
                if r.returncode != 0:
                    wav = mp3
            else:
                r = subprocess.run(
                    ["ffmpeg", "-y", "-v", "error", "-i", mp3, wav],
                    capture_output=True, timeout=300)
                if r.returncode != 0:
                    wav = mp3
            chunks.append((s, wav))

        if not chunks:
            raise RuntimeError("All TTS segments failed")

        # 4. assemble timeline: silent base + delayed chunks
        prog(0.75, "Assembling dubbed audio…")
        total = vid_dur if vid_dur > 0 else max(s for s, _ in chunks) + 60
        base = os.path.join(workdir, "base.wav")
        subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
             "anullsrc=r=44100:cl=stereo:d=%.1f" % total, base],
            check=True, timeout=120)
        inputs, fcs = ["-i", base], []
        for i, (s, wav) in enumerate(chunks):
            inputs += ["-i", wav]
            ms = int(s * 1000)
            fcs.append("[%d:a]adelay=%d|%d,apad[a%d]" % (i + 1, ms, ms, i))
        fcs.append("[0:a]" + "".join("[a%d]" % i for i in range(len(chunks)))
                   + "amix=inputs=%d:normalize=0,dynaudnorm[aout]"
                   % (len(chunks) + 1))
        mixed = os.path.join(workdir, "mixed.wav")
        r = subprocess.run(
            ["ffmpeg", "-y", "-v", "error"] + inputs +
            ["-filter_complex", ";".join(fcs), "-map", "[aout]",
             "-t", "%.1f" % total, mixed],
            capture_output=True, text=True, timeout=900)
        if r.returncode != 0:
            raise RuntimeError("Audio mix failed: " + r.stderr[-300:])

        # 5. mux: replace original audio
        prog(0.9, "Muxing dubbed audio into video…")
        r = subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", video_path, "-i", mixed,
             "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
             "-map", "0:v:0", "-map", "1:a:0", "-shortest", output_path],
            capture_output=True, text=True, timeout=900)
        if r.returncode != 0 or not os.path.exists(output_path):
            raise RuntimeError("Mux failed: " + r.stderr[-300:])
        prog(1.0, "Done: %s" % output_path)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
    return output_path
