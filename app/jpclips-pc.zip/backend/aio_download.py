"""All-in-One (coder2077 "Download All in One") download route — v42 STUB.

Second RapidAPI route on the same account/key as DataFanatic
(rapidapi_download.py): meant to cover TikTok / Instagram / Facebook / X
links and to fail over YouTube when DataFanatic is down.

Its endpoint paths are not visible in the RapidAPI listing we have, and
guessed paths return 404 — so until the real endpoint is captured from
the API's playground page, every entry point raises AIONotConfigured
and the caller falls through to the yt-dlp chain. When the endpoint is
known, fill in the request + response parsing here; no caller changes.
"""


class AIONotConfigured(RuntimeError):
    """The Download All in One endpoint path has not been configured."""


def _not_configured(url):
    raise AIONotConfigured(
        "AIO endpoint not configured: the Download All in One endpoint "
        f"path is unknown, so {url!r} cannot be fetched through it yet")


def download_youtube_video(url, output_dir=".", api_key=None, on_audio=None):
    """YouTube failover slot in the download chain (see main.py)."""
    _not_configured(url)


def download_social_video(url, output_dir=".", api_key=None, on_audio=None):
    """Social-link slot (TikTok / Instagram / Facebook / X) in main.py."""
    _not_configured(url)
