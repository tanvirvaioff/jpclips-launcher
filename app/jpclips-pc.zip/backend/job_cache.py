"""Cross-job cache for transcripts and LLM moment analysis.

Keyed by a SHA256 of the video *content* (not the path), so re-running the
same video — or resuming a 50-video batch after an API quota dies — skips the
work that already succeeded:

* transcripts  -> JpClipsData/cache/transcripts/<hash>.json
* LLM analysis -> JpClipsData/cache/analysis/<hash>.json

Everything is best-effort: any failure returns None / does nothing, never
fails the job. Large files (>512MB) hash head+tail+size for speed.
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Optional

_CHUNK = 8 * 1024 * 1024
_BIG_FILE = 512 * 1024 * 1024
_EDGE = 32 * 1024 * 1024


def _data_root() -> str:
    # JpClipsData — one level above the app dir, next to api_keys.json.
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(os.path.dirname(backend_dir))


def cache_root() -> str:
    return os.path.join(_data_root(), "cache")


def video_hash(path: str) -> Optional[str]:
    """Content hash of a video file, or None when it cannot be hashed."""
    try:
        size = os.path.getsize(path)
        if size <= 0:
            return None
        h = hashlib.sha256()
        h.update(b"jpclips-v1:")
        h.update(str(size).encode())
        with open(path, "rb") as f:
            if size <= _BIG_FILE:
                while True:
                    chunk = f.read(_CHUNK)
                    if not chunk:
                        break
                    h.update(chunk)
            else:
                h.update(f.read(_EDGE))
                f.seek(max(0, size - _EDGE))
                h.update(f.read(_EDGE))
        return h.hexdigest()[:32]
    except Exception:
        return None


def _transcript_path(vhash: str) -> str:
    return os.path.join(cache_root(), "transcripts", vhash + ".json")


def _analysis_path(vhash: str) -> str:
    return os.path.join(cache_root(), "analysis", vhash + ".json")


def _read_json(path: str):
    try:
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _write_json(path: str, payload) -> bool:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def get_cached_transcript(vhash: Optional[str]):
    """A transcript dict for this video hash, or None."""
    if not vhash:
        return None
    data = _read_json(_transcript_path(vhash))
    if not isinstance(data, dict):
        return None
    t = data.get("transcript")
    if not isinstance(t, dict) or not t.get("segments"):
        return None
    return t


def save_transcript(vhash: Optional[str], transcript: dict) -> bool:
    if not vhash or not isinstance(transcript, dict) or not transcript.get("segments"):
        return False
    return _write_json(_transcript_path(vhash), {"v": 1, "transcript": transcript})


def get_cached_analysis(vhash: Optional[str]):
    """A clips_data dict ({"shorts": [...], ...}) for this video hash, or None."""
    if not vhash:
        return None
    data = _read_json(_analysis_path(vhash))
    if not isinstance(data, dict):
        return None
    clips = data.get("clips_data")
    if not isinstance(clips, dict) or not clips.get("shorts"):
        return None
    return clips


def save_analysis(vhash: Optional[str], clips_data: dict) -> bool:
    if not vhash or not isinstance(clips_data, dict) or not clips_data.get("shorts"):
        return False
    return _write_json(_analysis_path(vhash), {"v": 1, "clips_data": clips_data})


def cache_stats() -> dict:
    """Rough counts for the UI (best-effort)."""
    stats = {"transcripts": 0, "analyses": 0}
    try:
        tdir = os.path.join(cache_root(), "transcripts")
        adir = os.path.join(cache_root(), "analysis")
        if os.path.isdir(tdir):
            stats["transcripts"] = sum(1 for n in os.listdir(tdir) if n.endswith(".json"))
        if os.path.isdir(adir):
            stats["analyses"] = sum(1 for n in os.listdir(adir) if n.endswith(".json"))
    except Exception:
        pass
    return stats
