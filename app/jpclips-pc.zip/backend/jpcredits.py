"""
JpClips PC v42 — Supabase account session + credits (app side).

The desktop app holds the signed-in user's OWN Supabase access token and
spends credits through the self-service RPCs shipped in
jpclips-credits-v2-app.sql (charge_my_credits / refund_my_credits).
Those derive the user from auth.uid(), so the app can only ever charge
the account that is signed in. No service-role key ships in the app;
the only key here is the public publishable one.

Session state lives in memory plus a JSON file next to api_keys.json
(JpClipsData/jpclips_session.json), so a restart keeps the user signed
in. set_session() validates the token once against GET /auth/v1/user
(the app does not verify JWTs locally).
"""

import json
import math
import os
import urllib.error
import urllib.request

SUPABASE_URL = "https://ybiclvrdpdgqwecckasx.supabase.co"
PUBLISHABLE_KEY = "sb_publishable_v3sS8JaNX4vIsPhT3DomSg_Hj-cIW03"

_SESSION = {"access_token": "", "user_id": "", "email": ""}
_LOADED = False


def _data_root():
    # Same root app.py's _api_keys_path() computes for api_keys.json.
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(backend_dir)
    return os.path.dirname(app_dir)


def _session_path():
    override = os.environ.get("JPCLIPS_SESSION_FILE", "").strip()
    if override:
        return override
    return os.path.join(_data_root(), "jpclips_session.json")


def _load_from_disk():
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    try:
        with open(_session_path(), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and data.get("access_token"):
            _SESSION.update({
                "access_token": str(data.get("access_token") or ""),
                "user_id": str(data.get("user_id") or ""),
                "email": str(data.get("email") or ""),
            })
    except Exception:
        pass


def _save_to_disk():
    try:
        path = _session_path()
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_SESSION, f)
        os.replace(tmp, path)
    except Exception:
        pass


def has_session():
    _load_from_disk()
    return bool(_SESSION.get("access_token"))


def current_user():
    _load_from_disk()
    if not _SESSION.get("access_token"):
        return None
    return {"id": _SESSION.get("user_id") or "",
            "email": _SESSION.get("email") or ""}


def _request(method, path, token=None, body=None, timeout=20):
    """(status, parsed_json) — status 0 on a transport error."""
    headers = {"apikey": PUBLISHABLE_KEY, "Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(SUPABASE_URL + path, data=data,
                                 headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8").strip()
            return resp.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        try:
            raw = e.read().decode("utf-8").strip()
            return e.code, (json.loads(raw) if raw else None)
        except Exception:
            return e.code, None
    except Exception:
        return 0, None


def set_session(access_token):
    """Validate + store a Supabase access token (from the login screen).

    Returns the user's profile dict ({email, credits, plan}), or None
    when Supabase rejects the token."""
    global _LOADED
    token = (access_token or "").strip()
    if not token:
        return None
    status, user = _request("GET", "/auth/v1/user", token=token)
    if status != 200 or not isinstance(user, dict) or not user.get("id"):
        return None
    _SESSION.update({"access_token": token,
                     "user_id": str(user.get("id") or ""),
                     "email": str(user.get("email") or "")})
    _LOADED = True
    _save_to_disk()
    profile = get_profile()
    if profile is None:
        # Auth is valid but the profile row could not be read right now;
        # still report the session with what we know.
        return {"email": _SESSION["email"], "credits": None, "plan": None}
    return profile


def clear_session():
    _SESSION.update({"access_token": "", "user_id": "", "email": ""})
    try:
        os.remove(_session_path())
    except OSError:
        pass


def get_profile():
    """Fresh profile row for the signed-in user (RLS: own row only)."""
    _load_from_disk()
    token = _SESSION.get("access_token")
    if not token:
        return None
    status, rows = _request(
        "GET", "/rest/v1/profiles?select=email,credits,plan", token=token)
    if status != 200 or not isinstance(rows, list) or not rows:
        return None
    row = dict(rows[0])
    if not row.get("email"):
        row["email"] = _SESSION.get("email") or ""
    return row


def _rpc(fn, body):
    _load_from_disk()
    token = _SESSION.get("access_token")
    if not token:
        return None
    status, res = _request("POST", "/rest/v1/rpc/" + fn, token=token, body=body)
    if status != 200:
        return None
    try:
        return int(res)
    except (TypeError, ValueError):
        return None


def charge_credits(amount, job_id):
    """Charge ``amount`` credits (1 per source minute) for ``job_id``.

    Returns the new balance, -1 when the balance is insufficient, -2
    when there is no valid session, or None on a transport error."""
    amount = max(1, int(math.ceil(float(amount))))
    return _rpc("charge_my_credits", {"p_amount": amount, "p_job": str(job_id)})


def refund_credits(job_id, amount):
    """Refund a previously charged job. Returns the new balance, -2
    when no matching un-refunded charge exists, or None on error."""
    return _rpc("refund_my_credits",
                {"p_amount": max(1, int(amount)), "p_job": str(job_id)})
