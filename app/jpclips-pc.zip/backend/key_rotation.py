"""Per-provider API key rotation + provider fallback chain for the moment picker.

The desktop app passes every configured key through the worker environment::

    JPCLIPS_LLM_KEYS='{"openai": ["sk-..", ..], "gemini": ["AI..", ..], "groq": ["gsk_..", ..]}'
    JPCLIPS_PROVIDER_ORDER='openai,gemini,groq'

``call_with_fallback`` tries providers in order; inside a provider it walks the
keys round-robin. A key that fails with a quota (429) or auth (401/403) error
is marked failed (1h cooldown) and the next key is tried. Only when every
provider/key is exhausted does the job fail — one dead provider never kills a
batch.

Worker env also keeps the legacy single-key vars (GEMINI_API_KEY / LLM_API_KEY)
for code paths that predate this module; the fallback chain is used whenever
JPCLIPS_LLM_KEYS carries at least one key.
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

PROVIDERS: Tuple[str, ...] = ("openai", "gemini", "groq")
DEFAULT_ORDER: List[str] = ["openai", "gemini", "groq"]
FAILED_COOLDOWN_SECONDS = 3600  # a failed key is retried after 1 hour

# Per-provider call presets for the OpenAI-compatible chat API.
OPENAI_COMPAT_PRESETS = {
    "openai": {"base_url": "https://api.openai.com/v1", "model_env": "OPENAI_MODEL",
               "default_model": "gpt-4o-mini"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "model_env": "GROQ_MODEL",
              "default_model": "llama-3.3-70b-versatile"},
}

GEMINI_MODEL_ENV = "GEMINI_MODEL"
GEMINI_DEFAULT_MODEL = "gemini-3.1-flash-lite"  # matches main.py legacy default


def model_for(provider: str) -> str:
    """Model name for a provider, honouring explicit env overrides."""
    if provider == "gemini":
        return (os.environ.get(GEMINI_MODEL_ENV) or "").strip() or GEMINI_DEFAULT_MODEL
    preset = OPENAI_COMPAT_PRESETS.get(provider)
    if preset:
        return (os.environ.get(preset["model_env"]) or "").strip() or preset["default_model"]
    return ""


def base_url_for(provider: str) -> str:
    preset = OPENAI_COMPAT_PRESETS.get(provider)
    return preset["base_url"] if preset else ""


class KeyRing:
    """Round-robin key rotation with failure cooldown, per provider."""

    def __init__(self, keys: Optional[Dict[str, List[str]]] = None,
                 order: Optional[List[str]] = None):
        self.keys: Dict[str, List[str]] = {}
        for p in PROVIDERS:
            raw = (keys or {}).get(p) or []
            seen, clean = set(), []
            for k in raw:
                k = str(k or "").strip()
                if k and k not in seen:
                    seen.add(k)
                    clean.append(k)
            self.keys[p] = clean[:20]
        order = [p for p in (order or []) if p in PROVIDERS]
        self.order: List[str] = order or list(DEFAULT_ORDER)
        self._idx = {p: 0 for p in PROVIDERS}
        self._failed: Dict[str, Dict[str, float]] = {p: {} for p in PROVIDERS}
        # The early-transcription thread and the main thread can both draw
        # keys; guard the round-robin cursor and failure map.
        self._lock = threading.Lock()

    def _usable(self, provider: str) -> List[str]:
        now = time.time()
        failed = self._failed.get(provider, {})
        return [k for k in self.keys.get(provider, [])
                if failed.get(k, 0) + FAILED_COOLDOWN_SECONDS < now]

    def next_key(self, provider: str) -> Optional[str]:
        with self._lock:
            usable = self._usable(provider)
            if not usable:
                return None
            i = self._idx[provider] % len(usable)
            self._idx[provider] = (self._idx[provider] + 1) % max(1, len(usable))
            return usable[i]

    def mark_failed(self, provider: str, key: str) -> None:
        with self._lock:
            self._failed.setdefault(provider, {})[key] = time.time()

    def configured_count(self, provider: str) -> int:
        return len(self.keys.get(provider, []))

    def has_any(self) -> bool:
        return any(self.keys.get(p) for p in PROVIDERS)

    def failed_count(self, provider: str) -> int:
        now = time.time()
        return sum(1 for ts in self._failed.get(provider, {}).values()
                   if ts + FAILED_COOLDOWN_SECONDS >= now)


def load_ring() -> KeyRing:
    """Build the ring from worker env (set by app.py when spawning the job)."""
    try:
        keys = json.loads(os.environ.get("JPCLIPS_LLM_KEYS") or "{}")
    except Exception:
        keys = {}
    if not isinstance(keys, dict):
        keys = {}
    raw_order = (os.environ.get("JPCLIPS_PROVIDER_ORDER") or "").strip()
    order = [p.strip().lower() for p in raw_order.split(",")
             if p.strip().lower() in PROVIDERS] or None
    return KeyRing(keys, order)


_RING: Optional[KeyRing] = None


def get_ring() -> KeyRing:
    global _RING
    if _RING is None:
        _RING = load_ring()
    return _RING


def reset_ring() -> None:
    """For tests only."""
    global _RING
    _RING = None


def fallback_configured() -> bool:
    """True when the worker env carries at least one cloud LLM key."""
    try:
        return get_ring().has_any()
    except Exception:
        return False


# Set by call_with_fallback to the provider that served the last successful
# call; main.py reads it to tag cache entries and logs.
last_provider: Optional[str] = None


_QUOTA_TOKENS = (
    "429", "resource_exhausted", "quota", "insufficient_quota",
    "rate_limit", "ratelimit", "too many requests", "quota_exceeded",
    "exceeded your current quota", "billing_hard_limit",
)
_AUTH_TOKENS = (
    "401", "403", "invalid_api_key", "invalid api key", "incorrect api key",
    "unauthorized", "api_key_invalid", "api key not valid",
    "authentication_error", "permission_denied", "forbidden",
)


def error_kind(exc: BaseException) -> str:
    """Classify an LLM failure: 'quota' | 'auth' | 'other'."""
    try:
        msg = f"{type(exc).__name__}: {exc}".lower()
    except Exception:
        return "other"
    if any(t in msg for t in _QUOTA_TOKENS):
        return "quota"
    if any(t in msg for t in _AUTH_TOKENS):
        return "auth"
    return "other"


def call_with_fallback(call_fn: Callable[[str, str, str], Tuple[dict, Optional[dict]]],
                       label: str = "LLM") -> Tuple[dict, Optional[dict]]:
    """Run ``call_fn(provider, key, model)`` across the fallback chain.

    ``call_fn`` must raise quota/auth failures immediately (no retry of a dead
    key) and may retry transient errors internally. Returns the first success.
    Raises RuntimeError only when every provider/key is exhausted.
    """
    global last_provider
    ring = get_ring()
    if not ring.has_any():
        raise RuntimeError(
            "No LLM API keys configured — add at least one key in the AI Keys card.")
    failures: List[str] = []
    for provider in ring.order:
        tried = 0
        budget = max(1, ring.configured_count(provider))
        while tried < budget:
            key = ring.next_key(provider)
            if key is None:
                break
            tried += 1
            model = model_for(provider)
            try:
                result = call_fn(provider, key, model)
            except Exception as e:
                kind = error_kind(e)
                if kind in ("quota", "auth"):
                    ring.mark_failed(provider, key)
                    failures.append(f"{provider}#{tried}({kind})")
                    print(f"   ⚠️ {label}: {provider} key #{tried} failed ({kind}) — "
                          f"trying next key... ({str(e)[:120]})")
                    continue
                raise
            last_provider = provider
            if tried > 1 or provider != ring.order[0]:
                print(f"   ✅ {label}: served by {provider} (key #{tried})")
            return result
        print(f"   ⚠️ {label}: provider '{provider}' exhausted — trying next provider...")
    raise RuntimeError(
        "All LLM providers/keys exhausted (%s). Add a fresh key or top up quota, "
        "then re-run — completed videos are cached and will be skipped."
        % (", ".join(failures[-4:]) if failures else "no keys usable"))


def rotate_gemini_key(call_fn: Callable[[str], Tuple[dict, Optional[dict]]],
                      label: str = "Gemini") -> Tuple[dict, Optional[dict]]:
    """Gemini-only rotation (vision path — OpenAI/Groq cannot see video).

    ``call_fn(key)`` is retried over every usable Gemini key on quota/auth
    errors; other errors propagate.
    """
    ring = get_ring()
    keys = ring.keys.get("gemini", [])
    if not keys:
        # Legacy single-key env fallback (pre-v24 workers).
        legacy = (os.environ.get("GEMINI_API_KEY") or "").strip()
        if not legacy:
            raise RuntimeError("GEMINI_API_KEY not found.")
        return call_fn(legacy)
    failures: List[str] = []
    tried = 0
    while tried < len(keys):
        key = ring.next_key("gemini")
        if key is None:
            break
        tried += 1
        try:
            return call_fn(key)
        except Exception as e:
            kind = error_kind(e)
            if kind in ("quota", "auth"):
                ring.mark_failed("gemini", key)
                failures.append(f"key#{tried}({kind})")
                print(f"   ⚠️ {label}: Gemini key #{tried} failed ({kind}) — "
                      f"trying next... ({str(e)[:120]})")
                continue
            raise
    raise RuntimeError(
        "All Gemini keys exhausted (%s). Gemini vision needs a working key."
        % (", ".join(failures[-3:]) if failures else "no keys usable"))
