"""JpClips server-side license gate (v32).

Keys are issued from the JioPagla admin panel (Supabase backend) and verified
against the Cloudflare Worker API. The key lives in
JpClipsData/license.json (next to api_keys.json), so app-code updates never
wipe activation. Free trial keys (48h) and paid keys work the same way.
"""
import json
import os
import time

import requests

API_BASE = "https://square-morning-8151.nubain99nubin.workers.dev"
TOOL_ID = "jpclips"
_CACHE_OK_SECONDS = 6 * 3600  # re-verify server-side at most every 6 hours


def _license_path():
    override = os.environ.get("JPCLIPS_LICENSE_FILE", "").strip()
    if override:
        return override
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(backend_dir)
    data_root = os.path.dirname(app_dir)
    return os.path.join(data_root, "license.json")


def _load():
    try:
        with open(_license_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data):
    try:
        os.makedirs(os.path.dirname(_license_path()), exist_ok=True)
        with open(_license_path(), "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


def verify_key(key):
    """Ask the license server. Returns the server dict, or None on network error."""
    try:
        r = requests.post(API_BASE + "/api/key/verify", json={"key": key}, timeout=12)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


def activate(key):
    key = (key or "").strip()
    if not key:
        return {"ok": False, "error": "Enter your license key."}
    res = verify_key(key)
    if res is None:
        return {"ok": False, "error": "Could not reach the license server. Check your internet connection and try again."}
    if not res.get("valid"):
        return {"ok": False, "error": "This key is invalid or expired."}
    if res.get("tool_id") not in (TOOL_ID, None):
        return {"ok": False, "error": "This key is for a different product."}
    _save({"key": key, "type": res.get("type"), "expires_at": res.get("expires_at"),
           "checked_at": time.time(), "valid": True})
    return {"ok": True, "type": res.get("type"), "expires_at": res.get("expires_at")}


def _expired(data):
    exp = data.get("expires_at")
    if not exp:
        return False
    try:
        from datetime import datetime, timezone
        return datetime.fromisoformat(str(exp).replace("Z", "+00:00")) < datetime.now(timezone.utc)
    except Exception:
        return False


def is_licensed():
    data = _load()
    key = (data.get("key") or "").strip()
    if not key:
        return False
    if _expired(data):
        return False
    now = time.time()
    if now - float(data.get("checked_at") or 0) < _CACHE_OK_SECONDS and data.get("valid"):
        return True
    res = verify_key(key)
    if res is None:
        # Offline: trust the last known-good state (unless it expired, checked above).
        return bool(data.get("valid"))
    ok = bool(res.get("valid")) and res.get("tool_id") in (TOOL_ID, None)
    _save({"key": key, "type": res.get("type"), "expires_at": res.get("expires_at"),
           "checked_at": now, "valid": ok})
    return ok


def status():
    data = _load()
    key = (data.get("key") or "").strip()
    if not key:
        return {"licensed": False}
    return {"licensed": is_licensed(), "type": data.get("type"), "expires_at": data.get("expires_at")}


ACTIVATE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Activate JpClips</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Segoe UI,system-ui,Arial,sans-serif;background:#0b0e1a;color:#eef0ff;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:#12162a;border:1px solid #262c47;border-radius:20px;padding:40px;width:100%;max-width:420px;text-align:center}
h1{margin:0 0 6px;font-size:24px}h1 span{background:linear-gradient(135deg,#7c5cff,#00d4ff);-webkit-background-clip:text;background-clip:text;color:transparent}
p.sub{color:#9aa3c7;font-size:13px;margin:0 0 24px}
input{width:100%;background:#0d1122;border:1px solid #262c47;color:#eef0ff;border-radius:12px;padding:13px;font-size:15px;text-align:center;letter-spacing:1px;outline:none}
input:focus{border-color:#7c5cff}
button{width:100%;margin-top:14px;background:linear-gradient(135deg,#7c5cff,#00d4ff);color:#fff;border:none;border-radius:12px;padding:13px;font-size:15px;font-weight:700;cursor:pointer}
button:disabled{opacity:.5;cursor:wait}
.err{color:#f87171;font-size:13px;margin-top:12px;min-height:18px}
.links{margin-top:20px;font-size:13px;color:#9aa3c7}.links a{color:#00d4ff;text-decoration:none}
</style></head><body>
<div class="card">
<h1>JpClips <span>Pro</span></h1>
<p class="sub">Enter your license key to activate. Trial keys work for 48 hours.</p>
<input id="key" placeholder="JPG-XXXX-XXXX or TRIAL-XXXX-XXXX" autocomplete="off">
<button id="btn" onclick="go()">Activate</button>
<div class="err" id="err"></div>
<div class="links">Need a key? <a href="https://jiopaglaltd.com" target="_blank">Get one on jiopaglaltd.com</a></div>
</div>
<script>
function go(){
  var k=document.getElementById('key').value.trim();
  var e=document.getElementById('err'); var b=document.getElementById('btn');
  e.textContent=''; b.disabled=true; b.textContent='Checking\\u2026';
  fetch('/api/activate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({key:k})})
    .then(function(r){return r.json()})
    .then(function(d){
      if(d.ok){ window.location.href='/'; }
      else { e.textContent=d.error||'Activation failed'; b.disabled=false; b.textContent='Activate'; }
    }).catch(function(){ e.textContent='Could not reach the server.'; b.disabled=false; b.textContent='Activate'; });
}
document.getElementById('key').addEventListener('keydown',function(ev){ if(ev.key==='Enter') go(); });
</script>
</body></html>"""
