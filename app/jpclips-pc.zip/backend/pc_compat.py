"""Windows compatibility patches for the JpClips backend.

Import this BEFORE importing app.py. It patches POSIX-only calls so the
backend runs on Windows:

1. subprocess.Popen(preexec_fn=...) - preexec_fn is POSIX-only and raises
   ValueError on Windows. We strip it (job priority lowering is skipped).
2. os.nice() - not available on Windows (only called via preexec_fn anyway).
"""
import os
import subprocess
import sys

if sys.platform == "win32":
    _orig_popen = subprocess.Popen

    def _patched_popen(*args, **kwargs):
        # preexec_fn is not supported on Windows - drop it silently.
        # (It was only used to lower job process priority via os.nice.)
        kwargs.pop("preexec_fn", None)
        return _orig_popen(*args, **kwargs)

    subprocess.Popen = _patched_popen

    # os.nice doesn't exist on Windows; provide a no-op in case anything
    # calls it directly.
    if not hasattr(os, "nice"):
        os.nice = lambda *a, **k: 0
