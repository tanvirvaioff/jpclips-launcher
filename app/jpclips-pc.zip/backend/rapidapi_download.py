"""RapidAPI (DataFanatic "YouTube Media Downloader") download route — v42.

Desktop-app YouTube downloads through yt-dlp kept hitting bot checks.
This module fetches the format list from
youtube-media-downloader.p.rapidapi.com, downloads the 1080p avc1 video
track plus the best m4a audio track straight from googlevideo (the
signed URLs download from any IP — live-tested 21-oct-2026, HTTP 206 on
range probes) and merges them with ``ffmpeg -c copy``.

Same contract as ``main.download_youtube_video``: returns
``(merged_path, sanitized_title)`` and honours ``on_audio(path,
duration)`` — the audio track is handed over as soon as it lands so the
caller can transcribe while the video is still downloading.

Key source: env ``RAPIDAPI_KEY`` first, else the ``rapidapi`` entry of
the app keys store (the api_keys.json that POST /api/keys writes; see
``get_rapidapi_key``). No key value is hardcoded here.
"""

import json
import os
import re
import subprocess
import unicodedata

import requests

API_HOST = "youtube-media-downloader.p.rapidapi.com"
API_URL = "https://" + API_HOST + "/v2/video/details"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")


class RapidAPIError(RuntimeError):
    """Any DataFanatic failure; the caller falls back to the next route."""


# ---------------------------------------------------------------------------
# Key lookup (mirrors app.py's _api_keys_path)
# ---------------------------------------------------------------------------

def get_rapidapi_key():
    """Env RAPIDAPI_KEY, else the keys store's ``rapidapi`` entry, else ''."""
    key = os.environ.get("RAPIDAPI_KEY", "").strip()
    if key:
        return key
    try:
        override = os.environ.get("JPCLIPS_KEYS_FILE", "").strip()
        if override:
            path = override
        else:
            backend_dir = os.path.dirname(os.path.abspath(__file__))
            app_dir = os.path.dirname(backend_dir)
            data_root = os.path.dirname(app_dir)
            path = os.path.join(data_root, "api_keys.json")
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            value = data.get("rapidapi")
            if isinstance(value, str) and value.strip():
                return value.strip()
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Video id + details
# ---------------------------------------------------------------------------

_ID_PATTERNS = (
    re.compile(r"youtube\.com/watch\?[^#]*\bv=([A-Za-z0-9_-]{11})"),
    re.compile(r"youtube\.com/(?:shorts|embed|live|v|e)/([A-Za-z0-9_-]{11})"),
    re.compile(r"youtu\.be/([A-Za-z0-9_-]{11})"),
)


def extract_video_id(url):
    """The 11-char video id from a watch / youtu.be / shorts / embed /
    live / v link, or None."""
    if not url:
        return None
    for pattern in _ID_PATTERNS:
        m = pattern.search(url)
        if m:
            return m.group(1)
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", url.strip()):
        return url.strip()
    return None


def fetch_details(video_id, api_key):
    """GET /v2/video/details for ``video_id``; RapidAPIError on any failure."""
    if not api_key:
        raise RapidAPIError("RAPIDAPI_KEY not set")
    try:
        resp = requests.get(
            API_URL,
            params={"videoId": video_id},
            headers={"x-rapidapi-key": api_key, "x-rapidapi-host": API_HOST},
            timeout=60,
        )
    except requests.RequestException as e:
        raise RapidAPIError(f"DataFanatic request failed: {e}") from e
    if resp.status_code in (401, 403):
        raise RapidAPIError(
            f"DataFanatic rejected the API key (HTTP {resp.status_code})")
    if resp.status_code == 429:
        raise RapidAPIError("DataFanatic quota / rate limit (HTTP 429)")
    if resp.status_code != 200:
        raise RapidAPIError(
            f"DataFanatic HTTP {resp.status_code}: {resp.text[:200]}")
    try:
        data = resp.json()
    except ValueError as e:
        raise RapidAPIError("DataFanatic returned a non-JSON response") from e
    if isinstance(data, dict) and data.get("error"):
        raise RapidAPIError(f"DataFanatic error: {str(data.get('error'))[:200]}")
    return data


# ---------------------------------------------------------------------------
# Format picking
# ---------------------------------------------------------------------------

def _items(container):
    if isinstance(container, dict):
        items = container.get("items")
        return items if isinstance(items, list) else []
    if isinstance(container, list):
        return container
    return []


def _height(item):
    try:
        h = int(item.get("height") or 0)
        if h:
            return h
    except (TypeError, ValueError):
        pass
    m = re.search(r"(\d{3,4})\s*p", str(item.get("quality") or ""))
    return int(m.group(1)) if m else 0


def _size(item):
    try:
        s = int(item.get("size") or 0)
        if s:
            return s
    except (TypeError, ValueError):
        pass
    m = re.match(r"([\d.]+)\s*(KB|MB|GB|B)?", str(item.get("sizeText") or ""))
    if not m:
        return 0
    mult = {"KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3, "B": 1}[m.group(2) or "B"]
    return int(float(m.group(1)) * mult)


def pick_formats(details):
    """(video_item, audio_item|None): 1080p avc1 mp4 first (video-only,
    audio merged from the separate track), then 1080p any mp4, then the
    best muxed item, then the largest mp4. Audio = largest audio/mp4."""
    videos = [v for v in _items((details or {}).get("videos"))
              if isinstance(v, dict) and v.get("url")]
    audios = [a for a in _items((details or {}).get("audios"))
              if isinstance(a, dict) and a.get("url")]
    if not videos:
        raise RapidAPIError("DataFanatic returned no video formats")
    mp4s = [v for v in videos if "mp4" in str(v.get("mimeType") or "video/mp4")]
    pool = mp4s or videos

    def avc1(v):
        return "avc1" in str(v.get("mimeType") or "")

    def muxed(v):
        return bool(v.get("hasAudio"))

    groups = [
        [v for v in pool if _height(v) == 1080 and avc1(v) and not muxed(v)],
        [v for v in pool if _height(v) == 1080 and not muxed(v)],
        [v for v in pool if _height(v) == 1080],
        [v for v in pool if _height(v) > 1080 and not muxed(v)],
        [v for v in pool if muxed(v)],
        pool,
    ]
    video = None
    for group in groups:
        if group:
            video = max(group, key=_size)
            break

    audio = None
    if not muxed(video):
        m4a = [a for a in audios if "audio/mp4" in str(a.get("mimeType") or "")]
        audio_pool = m4a or audios
        if audio_pool:
            audio = max(audio_pool, key=_size)
    return video, audio


# ---------------------------------------------------------------------------
# Download + merge
# ---------------------------------------------------------------------------

def _sanitize_title(title):
    title = unicodedata.normalize("NFC", str(title or "video"))
    title = re.sub(r'[<>:"/\\|?*#]', "", title).strip().replace(" ", "_")
    return title[:100] or "video"


def _download_file(url, dest):
    try:
        with requests.get(url, headers={"User-Agent": _UA},
                          stream=True, timeout=120) as resp:
            if resp.status_code != 200:
                raise RapidAPIError(
                    f"media download HTTP {resp.status_code} for {dest}")
            with open(dest, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1024 * 512):
                    if chunk:
                        f.write(chunk)
    except requests.RequestException as e:
        raise RapidAPIError(f"media download failed: {e}") from e
    if not os.path.exists(dest) or os.path.getsize(dest) == 0:
        raise RapidAPIError(f"media download produced an empty file: {dest}")


def _duration_of(path):
    try:
        proc = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", path],
            capture_output=True, timeout=30)
        return float(proc.stdout.decode().strip() or 0)
    except Exception:
        return 0.0


def _merge(video_path, audio_path, out_path):
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
           "-i", video_path, "-i", audio_path,
           "-c", "copy", "-movflags", "+faststart", out_path]
    proc = subprocess.run(cmd, capture_output=True, timeout=1800)
    if proc.returncode != 0 or not os.path.exists(out_path) \
            or os.path.getsize(out_path) == 0:
        raise RapidAPIError(
            "ffmpeg merge failed: " + proc.stderr.decode(errors="replace")[:300])


def download_youtube_video(url, output_dir=".", api_key=None, on_audio=None):
    """Download ``url`` through DataFanatic. Returns (path, title).

    ``on_audio(path, duration)`` fires with the audio track as soon as it
    lands (same contract as the yt-dlp route in main.py)."""
    if api_key is None:
        api_key = get_rapidapi_key()
    if not api_key:
        raise RapidAPIError("RAPIDAPI_KEY not set")
    video_id = extract_video_id(url)
    if not video_id:
        raise RapidAPIError(f"no video id in URL: {url!r}")
    details = fetch_details(video_id, api_key)
    video_item, audio_item = pick_formats(details)
    title = _sanitize_title(details.get("title") or video_id)
    os.makedirs(output_dir, exist_ok=True)
    dest = os.path.join(output_dir, title + ".mp4")

    if audio_item is None:
        # Muxed format (audio included): a single download, no merge.
        _download_file(video_item["url"], dest)
        return dest, title

    audio_tmp = os.path.join(output_dir, title + ".audio.m4a")
    video_tmp = os.path.join(output_dir, title + ".video.mp4")
    _download_file(audio_item["url"], audio_tmp)
    if on_audio is not None:
        try:
            on_audio(audio_tmp,
                     _duration_of(audio_tmp)
                     or float(details.get("lengthSeconds") or 0))
        except Exception:
            pass
    _download_file(video_item["url"], video_tmp)
    _merge(video_tmp, audio_tmp, dest)
    try:
        os.remove(video_tmp)
    except OSError:
        pass
    if on_audio is None:
        # Nobody is transcribing from the side file: the merged mp4 has
        # the same audio, so the temp is safe to drop. (When on_audio
        # fired, the caller owns the file's lifecycle.)
        try:
            os.remove(audio_tmp)
        except OSError:
            pass
    return dest, title
