"""Lightweight speaker diarization for multi-voice dubbing.

No pyannote / no extra models: uses transcript segments as speech units,
extracts per-segment voice features with numpy only, and clusters with a
tiny KMeans. Good enough for the common case (podcast / interview with
2-3 alternating speakers). Falls back to a single speaker on any failure.

Public API:
    diarize_speakers(media_path, segments=None, max_speakers=3) -> dict
"""

import os
import subprocess
import tempfile

import numpy as np

_SR = 16000  # analysis sample rate


# --------------------------------------------------------------------------
# audio loading
# --------------------------------------------------------------------------

def _load_mono_16k(media_path):
    """Decode to mono 16kHz float32 numpy array via ffmpeg."""
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf:
        wav = tf.name
    try:
        r = subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", media_path,
             "-ac", "1", "-ar", str(_SR), "-f", "wav", wav],
            capture_output=True, timeout=600)
        if r.returncode != 0 or not os.path.exists(wav):
            raise RuntimeError("ffmpeg decode failed")
        import wave
        with wave.open(wav, "rb") as w:
            n = w.getnframes()
            raw = w.readframes(n)
        x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        return x
    finally:
        try:
            os.unlink(wav)
        except Exception:
            pass


# --------------------------------------------------------------------------
# per-segment voice features (numpy only)
# --------------------------------------------------------------------------

def _estimate_f0_median(x, sr=_SR):
    """Median F0 over voiced 30ms frames via autocorrelation. 0.0 if none."""
    frame_len = int(sr * 0.03)
    hop = int(sr * 0.015)
    if len(x) < frame_len * 2:
        return 0.0
    win = np.hanning(frame_len)
    min_lag = max(2, int(sr / 500))
    max_lag = int(sr / 50)
    f0s = []
    for start in range(0, len(x) - frame_len, hop):
        frame = x[start:start + frame_len] * win
        if np.max(np.abs(frame)) < 0.02:
            continue
        corr = np.correlate(frame, frame, mode="full")[frame_len - 1:]
        if max_lag >= len(corr):
            continue
        seg = corr[min_lag:max_lag]
        peak = int(np.argmax(seg)) + min_lag
        # voicing: autocorrelation peak must stand out
        if corr[peak] > 0.35 * corr[0] and corr[peak] > 1e-6:
            f0s.append(sr / peak)
    if len(f0s) < 3:
        return 0.0
    return float(np.median(f0s))


def _spectral_features(x, sr=_SR):
    """Mean spectral centroid / rolloff / zcr / band energies over frames."""
    frame_len = 2048
    hop = 1024
    if len(x) < frame_len:
        x = np.pad(x, (0, frame_len - len(x)))
    win = np.hanning(frame_len)
    freqs = np.fft.rfftfreq(frame_len, 1.0 / sr)
    cents, rolls, zcrs = [], [], []
    e_low, e_mid, e_high, e_tot = [], [], [], []
    for start in range(0, len(x) - frame_len + 1, hop):
        frame = x[start:start + frame_len] * win
        mag = np.abs(np.fft.rfft(frame))
        tot = float(np.sum(mag)) + 1e-9
        cents.append(float(np.sum(freqs * mag) / tot))
        cum = np.cumsum(mag)
        roll = freqs[int(np.searchsorted(cum, 0.85 * tot))]
        rolls.append(float(roll))
        zcrs.append(float(np.mean(np.abs(np.diff(np.sign(frame)))) / 2.0))
        e_low.append(float(np.sum(mag[freqs < 1000])))
        e_mid.append(float(np.sum(mag[(freqs >= 1000) & (freqs < 4000)])))
        e_high.append(float(np.sum(mag[freqs >= 4000])))
        e_tot.append(tot)
    e_tot = np.array(e_tot) + 1e-9
    return {
        "centroid": float(np.mean(cents)),
        "rolloff": float(np.mean(rolls)),
        "zcr": float(np.mean(zcrs)),
        "low_ratio": float(np.mean(np.array(e_low) / e_tot)),
        "mid_ratio": float(np.mean(np.array(e_mid) / e_tot)),
        "high_ratio": float(np.mean(np.array(e_high) / e_tot)),
    }


def _segment_features(x, sr=_SR):
    """Feature vector for one speech segment."""
    f0 = _estimate_f0_median(x, sr)
    sp = _spectral_features(x, sr)
    # log-scale pitch-ish features; 0 f0 -> neutral value filled later
    return np.array([
        np.log1p(f0),                       # pitch (weighted x2 below)
        np.log1p(f0),
        sp["centroid"] / 1000.0,
        sp["rolloff"] / 1000.0,
        sp["zcr"] * 10.0,
        sp["low_ratio"] * 5.0,
        sp["mid_ratio"] * 5.0,
        sp["high_ratio"] * 5.0,
    ], dtype=np.float64)


# --------------------------------------------------------------------------
# tiny kmeans + separation score
# --------------------------------------------------------------------------

def _kmeans(X, k, seed=0, iters=60):
    rng = np.random.default_rng(seed)
    n = X.shape[0]
    # k-means++ init
    centers = [X[rng.integers(n)]]
    for _ in range(1, k):
        d2 = np.min(
            np.sum((X[:, None, :] - np.array(centers)[None, :, :]) ** 2,
                   axis=2), axis=1)
        tot = d2.sum()
        if tot < 1e-12:
            probs = np.full(n, 1.0 / n)  # all points identical -> uniform
        else:
            probs = d2 / tot
        centers.append(X[rng.choice(n, p=probs)])
    centers = np.array(centers)
    labels = np.zeros(n, dtype=int)
    for _ in range(iters):
        d = np.sum((X[:, None, :] - centers[None, :, :]) ** 2, axis=2)
        new_labels = np.argmin(d, axis=1)
        if np.array_equal(new_labels, labels):
            break
        labels = new_labels
        for c in range(k):
            pts = X[labels == c]
            if len(pts):
                centers[c] = pts.mean(axis=0)
    return labels, centers


def _separation_score(X, labels):
    """Mean silhouette-ish score in [0,1]. Higher = better separated."""
    n = len(X)
    if n < 3:
        return 0.0
    D = np.sqrt(np.sum((X[:, None, :] - X[None, :, :]) ** 2, axis=2)) + 1e-12
    s = []
    for i in range(n):
        same = (labels == labels[i])
        same[i] = False
        other = ~ (labels == labels[i])
        a = D[i][same].mean() if same.any() else 0.0
        b = D[i][other].mean() if other.any() else 0.0
        if max(a, b) > 0:
            s.append((b - a) / max(a, b))
    return float(np.mean(s)) if s else 0.0


# --------------------------------------------------------------------------
# main entry
# --------------------------------------------------------------------------

def _single_speaker_result(segments):
    segs = segments or []
    total = sum(max(0.0, float(s.get("end", 0)) - float(s.get("start", 0)))
                     for s in segs)
    sample = segs[len(segs) // 2] if segs else {}
    return {
        "speakers": [{
            "id": "spk1",
            "label": "Speaker 1",
            "num_segments": len(segs),
            "total_sec": round(total, 1),
            "sample": {
                "start": round(float(sample.get("start", 0)), 1),
                "end": round(float(sample.get("end", 0)), 1),
                "text": (sample.get("text") or "")[:160],
            },
        }],
        "segment_speakers": ["spk1"] * len(segs),
        "num_speakers": 1,
    }


def diarize_speakers(media_path, segments=None, max_speakers=3):
    """Detect speakers in media_path.

    segments: optional list of {"start","end","text"} (from transcription).
    Returns dict with speakers + per-segment speaker ids. Never raises:
    falls back to a single speaker.
    """
    try:
        return _diarize_inner(media_path, segments, max_speakers)
    except Exception as e:
        print(f"[diarize] failed ({e}) -> single speaker fallback",
              flush=True)
        try:
            return _single_speaker_result(segments or [])
        except Exception:
            return {"speakers": [], "segment_speakers": [],
                    "num_speakers": 1}


def _diarize_inner(media_path, segments, max_speakers):
    if segments is None:
        from transcribe_backends import transcribe_media
        tr = transcribe_media(media_path)
        segments = [s for s in tr.get("segments", [])
                    if (s.get("text") or "").strip()]
    segments = [s for s in segments
                if float(s.get("end", 0)) > float(s.get("start", 0))]
    if len(segments) < 4:
        return _single_speaker_result(segments)

    audio = _load_mono_16k(media_path)
    if len(audio) < _SR:
        return _single_speaker_result(segments)

    feats, valid_idx = [], []
    for i, s in enumerate(segments):
        dur = float(s["end"]) - float(s["start"])
        if dur < 0.6 or dur > 60:
            continue
        a = int(float(s["start"]) * _SR)
        b = int(float(s["end"]) * _SR)
        sl = audio[max(0, a):b]
        if len(sl) < int(_SR * 0.5):
            continue
        # skip near-silent slices
        if float(np.sqrt(np.mean(sl ** 2))) < 0.01:
            continue
        f = _segment_features(sl)
        if f[0] <= 0:  # no pitch detected -> unreliable, skip
            continue
        feats.append(f)
        valid_idx.append(i)

    if len(feats) < 4:
        return _single_speaker_result(segments)

    X = np.array(feats)
    # z-score normalize
    mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-9
    Xn = (X - mu) / sd

    best_k, best_labels, best_score = 1, np.zeros(len(Xn), dtype=int), 0.0
    for k in range(2, min(max_speakers, len(Xn) // 2) + 1):
        labels, _ = _kmeans(Xn, k, seed=7)
        # require every cluster to have >=2 members
        if any((labels == c).sum() < 2 for c in range(k)):
            continue
        score = _separation_score(Xn, labels)
        # higher k must beat lower k by a margin to be chosen
        if score > best_score + (0.08 if k > 2 else 0.0) and score > 0.22:
            best_k, best_labels, best_score = k, labels, score

    # map cluster labels -> speaker ids ordered by first appearance
    seg_speaker = ["spk1"] * len(segments)
    if best_k > 1:
        order = []
        for c in range(best_k):
            members = [valid_idx[j] for j in range(len(valid_idx))
                       if best_labels[j] == c]
            order.append((min(members), c))
        order.sort()
        cmap = {c: "spk%d" % (rank + 1) for rank, (_, c) in enumerate(order)}
        for j, vi in enumerate(valid_idx):
            seg_speaker[vi] = cmap[int(best_labels[j])]
        # short/skipped segments inherit nearest valid neighbour's speaker
        last = "spk1"
        for i in range(len(segments)):
            if i in set(valid_idx):
                last = seg_speaker[i]
            else:
                seg_speaker[i] = last

    speakers = []
    for spk_i in range(1, (best_k if best_k > 1 else 1) + 1):
        sid = "spk%d" % spk_i
        idxs = [i for i, s in enumerate(seg_speaker) if s == sid]
        total = sum(float(segments[i]["end"]) - float(segments[i]["start"])
                    for i in idxs)
        mid = idxs[len(idxs) // 2]
        smp = segments[mid]
        speakers.append({
            "id": sid,
            "label": "Speaker %d" % spk_i,
            "num_segments": len(idxs),
            "total_sec": round(total, 1),
            "sample": {
                "start": round(float(smp["start"]), 1),
                "end": round(float(smp["end"]), 1),
                "text": (smp.get("text") or "")[:160],
            },
        })

    print(f"[diarize] detected {len(speakers)} speaker(s) "
          f"(score={best_score:.2f}, segs={len(valid_idx)})", flush=True)
    return {"speakers": speakers, "segment_speakers": seg_speaker,
            "num_speakers": len(speakers)}
