@echo off
REM ============================================================
REM  JpClips PC - one-time installer
REM  Needs: Python 3.10 or 3.11 (64-bit) + NVIDIA GPU driver
REM  Run this ONCE, then use start.bat every time.
REM ============================================================
cd /d "%~dp0"

echo.
echo  [1/4] Checking Python...
python --version 2>nul
if errorlevel 1 (
    echo  ERROR: Python not found!
    echo  Install Python 3.11 64-bit from https://www.python.org/downloads/
    echo  IMPORTANT: tick "Add python.exe to PATH" during install.
    pause
    exit /b 1
)

echo.
echo  [2/4] Checking NVIDIA GPU...
nvidia-smi --query-gpu=name --format=csv,noheader > gpu.txt 2>nul
if errorlevel 1 (
    echo  WARNING: nvidia-smi not found - GPU may not be available.
    echo  Install your NVIDIA driver from https://www.nvidia.com/drivers
    echo  Continuing anyway ^(CPU fallback will be used^)...
) else (
    echo  GPU detected:
    type gpu.txt
)
del gpu.txt 2>nul

echo.
echo  [3/4] Installing PyTorch with CUDA 12.1 (this is big, ~2.5 GB)...
python -m pip install --upgrade pip
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
if errorlevel 1 (
    echo  ERROR: PyTorch install failed.
    pause
    exit /b 1
)

echo.
echo  [4/4] Installing JpClips requirements...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo  ERROR: requirements install failed.
    pause
    exit /b 1
)

echo.
echo  Checking ffmpeg...
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo  WARNING: ffmpeg not found on PATH.
    echo  Download from https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
    echo  Extract and add the bin folder to your PATH, then re-run start.bat.
) else (
    echo  ffmpeg OK
)

echo.
echo  ============================================================
echo   Install complete! Now double-click start.bat to run JpClips.
echo  ============================================================
pause
