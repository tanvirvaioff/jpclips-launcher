"""JpClips PC entry point.

1. Applies Windows compatibility patches (pc_compat).
2. Imports the FastAPI app from app.py.
3. Serves the built React frontend (frontend/) at / so the user just opens
   http://localhost:8000 in a browser. API routes (/api/...) registered in
   app.py take precedence over the static files.

Run with:  uvicorn pc_server:app --host 127.0.0.1 --port 8000
"""
import os
import sys

# Backend code lives in backend/ next to this file.
_here = os.path.dirname(os.path.abspath(__file__))
_backend = os.path.join(_here, "backend")
if _here not in sys.path:
    sys.path.insert(0, _here)
if _backend not in sys.path:
    sys.path.insert(0, _backend)

os.chdir(_backend)  # so relative paths (output/, main.py) resolve

import pc_compat  # noqa: F401  (applies Windows patches)

from fastapi.staticfiles import StaticFiles
from app import app  # noqa: E402

_frontend = os.path.join(_here, "frontend")
if os.path.isdir(_frontend) and os.path.exists(os.path.join(_frontend, "index.html")):
    # Mount AFTER all API routes are registered so /api/* etc. win.
    app.mount("/", StaticFiles(directory=_frontend, html=True), name="frontend")
else:
    print("WARNING: frontend/ not found - API only. Build the dashboard and",
          "copy dist/ to frontend/.")
