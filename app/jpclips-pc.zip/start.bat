@echo off
REM ============================================================
REM  JpClips PC - starts the AI clipper on your PC (uses your GPU)
REM  1. Put your API keys in Settings in the web UI (stored in browser)
REM  2. Open http://localhost:8000 in your browser
REM ============================================================
cd /d "%~dp0"

REM --- GPU settings ---
REM faster-whisper on CUDA with float16 = ~5-10x faster transcription
set WHISPER_DEVICE=cuda
set WHISPER_COMPUTE=float16
REM --- Parallel jobs: 2 videos at once (safe for most GPUs) ---
set MAX_CONCURRENT_JOBS=2

echo.
echo  ============================================================
echo   JpClips PC starting...
echo   Open http://localhost:8000 in your browser
echo   Press Ctrl+C to stop.
echo  ============================================================
echo.

python -m uvicorn pc_server:app --host 127.0.0.1 --port 8000
pause
